#ifndef LINKED_STACK_
#define LINKED_STACK_

#include "StackInterface.h"
#include "Node.h"
#include <cassert>

template<class ItemType>
class LinkedStack : public StackInterface<ItemType> {
private:
    Node<ItemType>* topPtr; // Pointer to first node in the chain

public:
    LinkedStack();
    LinkedStack(const LinkedStack<ItemType>& originalStack); 
    virtual ~LinkedStack();

    bool isEmpty() const noexcept override;
    bool push(const ItemType& someItem) override;
    bool pop() noexcept override;
    ItemType peek() const override;
};

// Implementation of LinkedStack

template<class ItemType>
LinkedStack<ItemType>::LinkedStack() : topPtr(nullptr) {}

template<class ItemType>
LinkedStack<ItemType>::LinkedStack(const LinkedStack<ItemType>& originalStack) {
    if (originalStack.topPtr == nullptr) {
        topPtr = nullptr;
    } else {
        topPtr = new Node<ItemType>();
        topPtr->setItem(originalStack.topPtr->getItem());

        Node<ItemType>* origPtr = originalStack.topPtr->getNext();
        Node<ItemType>* newPtr = topPtr;
        
        while (origPtr != nullptr) {
            newPtr->setNext(new Node<ItemType>(origPtr->getItem()));
            newPtr = newPtr->getNext();
            origPtr = origPtr->getNext();
        }
    }
}

template<class ItemType>
LinkedStack<ItemType>::~LinkedStack() {
    while (!isEmpty()) {
        pop();
    }
}

template<class ItemType>
bool LinkedStack<ItemType>::isEmpty() const noexcept {
    return topPtr == nullptr;
}

template<class ItemType>
bool LinkedStack<ItemType>::push(const ItemType& someItem) {
    Node<ItemType>* newNode = new Node<ItemType>(someItem, topPtr);
    topPtr = newNode;
    return true;
}

template<class ItemType>
bool LinkedStack<ItemType>::pop() noexcept {
    if (isEmpty()) return false;

    Node<ItemType>* nodeToDelete = topPtr;
    topPtr = topPtr->getNext();

    delete nodeToDelete;
    return true;
}

template<class ItemType>
ItemType LinkedStack<ItemType>::peek() const {
    assert(!isEmpty());
    return topPtr->getItem();
}

#endif
