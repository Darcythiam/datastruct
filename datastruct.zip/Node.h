#ifndef NODE_
#define NODE_

template<class ItemType>
class Node {
private:
    ItemType item;
    Node<ItemType>* next;

public:
    Node();
    Node(const ItemType& someItem);
    Node(const ItemType& someItem, Node<ItemType>* nextNodePtr);

    void setItem(const ItemType& someItem);
    void setNext(Node<ItemType>* nextNodePtr);

    ItemType getItem() const;
    Node<ItemType>* getNext() const;
};

// Implementations for Node
template<class ItemType>
Node<ItemType>::Node() : next(nullptr) {}

template<class ItemType>
Node<ItemType>::Node(const ItemType& someItem) : item(someItem), next(nullptr) {}

template<class ItemType>
Node<ItemType>::Node(const ItemType& someItem, Node<ItemType>* nextNodePtr)
    : item(someItem), next(nextNodePtr) {}

template<class ItemType>
void Node<ItemType>::setItem(const ItemType& someItem) {
    item = someItem;
}

template<class ItemType>
void Node<ItemType>::setNext(Node<ItemType>* nextNodePtr) {
    next = nextNodePtr;
}

template<class ItemType>
ItemType Node<ItemType>::getItem() const {
    return item;
}

template<class ItemType>
Node<ItemType>* Node<ItemType>::getNext() const {
    return next;
}

#endif
