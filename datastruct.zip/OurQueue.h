#ifndef OUR_QUEUE_
#define OUR_QUEUE_

#include "QueueInterface.h"
#include <queue>
#include <stdexcept>

template<class ItemType>
class OurQueue : public QueueInterface<ItemType> {
private:
    std::queue<ItemType> queue;

public:
    OurQueue() = default;

    bool isEmpty() const override {
        return queue.empty();
    }

    bool enqueue(const ItemType& someItem) override {
        queue.push(someItem);
        return true;
    }

    bool dequeue() override {
        if (isEmpty()) {
            return false;
        }
        queue.pop();
        return true;
    }

    ItemType peekFront() const override {
        if (isEmpty()) {
            throw std::runtime_error("Queue is empty. Cannot peek.");
        }
        return queue.front();
    }

    void clear() override {
        while (!isEmpty()) {
            queue.pop();
        }
    }
};

#endif
