#include <iostream>
#include <string>
#include <cctype>
#include "OurQueue.h"
#include "LinkedStack.h"

using namespace std;

// Palindrome Checker Function
bool isPalindrome(const string& str) {
    LinkedStack<char> stack;
    OurQueue<char> queue;

    for (char ch : str) {
        if (isalnum(ch)) {
            ch = tolower(ch);
            stack.push(ch);
            queue.enqueue(ch);
        }
    }

    while (!stack.isEmpty()) {
        if (stack.peek() != queue.peekFront()) {
            return false;
        }
        stack.pop();
        queue.dequeue();
    }

    return true;
}

// Menu Functions
void runStackOperations() {
    LinkedStack<int> stack;
    int choice, value;

    do {
        cout << "\nStack Operations Menu:" << endl;
        cout << "1. Push" << endl;
        cout << "2. Pop" << endl;
        cout << "3. Peek" << endl;
        cout << "4. Check if empty" << endl;
        cout << "5. Exit stack operations" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value to push: ";
            cin >> value;
            stack.push(value);
            cout << value << " pushed onto stack." << endl;
            break;
        case 2:
            if (stack.pop()) {
                cout << "Top element popped." << endl;
            } else {
                cout << "Stack is empty!" << endl;
            }
            break;
        case 3:
            if (!stack.isEmpty()) {
                cout << "Top element is: " << stack.peek() << endl;
            } else {
                cout << "Stack is empty!" << endl;
            }
            break;
        case 4:
            cout << (stack.isEmpty() ? "Stack is empty." : "Stack is not empty.") << endl;
            break;
        case 5:
            cout << "Exiting stack operations." << endl;
            break;
        default:
            cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 5);
}

void runQueueOperations() {
    OurQueue<int> queue;
    int choice, value;

    do {
        cout << "\nQueue Operations Menu:" << endl;
        cout << "1. Enqueue" << endl;
        cout << "2. Dequeue" << endl;
        cout << "3. Peek Front" << endl;
        cout << "4. Check if empty" << endl;
        cout << "5. Exit queue operations" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value to enqueue: ";
            cin >> value;
            queue.enqueue(value);
            cout << value << " enqueued." << endl;
            break;
        case 2:
            if (queue.dequeue()) {
                cout << "Front element dequeued." << endl;
            } else {
                cout << "Queue is empty!" << endl;
            }
            break;
        case 3:
            if (!queue.isEmpty()) {
                cout << "Front element is: " << queue.peekFront() << endl;
            } else {
                cout << "Queue is empty!" << endl;
            }
            break;
        case 4:
            cout << (queue.isEmpty() ? "Queue is empty." : "Queue is not empty.") << endl;
            break;
        case 5:
            cout << "Exiting queue operations." << endl;
            break;
        default:
            cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 5);
}

void runPalindromeChecker() {
    string input;
    cout << "Enter a string to check for palindrome: ";
    cin.ignore();  // Clear input buffer
    getline(cin, input);

    if (isPalindrome(input)) {
        cout << "\"" << input << "\" is a palindrome!" << endl;
    } else {
        cout << "\"" << input << "\" is not a palindrome." << endl;
    }
}

int main() {
    int choice;

    do {
        cout << "\nMain Menu:" << endl;
        cout << "1. Stack Operations" << endl;
        cout << "2. Queue Operations" << endl;
        cout << "3. Palindrome Checker" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            runStackOperations();
            break;
        case 2:
            runQueueOperations();
            break;
        case 3:
            runPalindromeChecker();
            break;
        case 4:
            cout << "Exiting program." << endl;
            break;
        default:
            cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 4);

    return 0;
}
